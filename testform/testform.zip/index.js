function showAlert() {
    alert("The PDF is dead.");
}